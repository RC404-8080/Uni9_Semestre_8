# Projeto Jogos Digitais

O projeto em questão era para realizar a criação de um jogo do inicio utilizando Goddot, foi desenvolvido um jogo estilo de luta com 3 cernarios e 4 lutadores diferentes (cada lutador com seus ataques e habilidades).
